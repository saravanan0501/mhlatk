<?php
/**
 * @category    Cluedy
 * @package     Cluedy
 * @copyright   Copyright © 2017 CleverSoft., JSC. All Rights Reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::THEME,
    'frontend/Magento/Mhlatk',
    __DIR__
);