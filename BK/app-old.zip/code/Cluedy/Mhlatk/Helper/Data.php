<?php
namespace Cluedy\Mhlatk\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
use Mageplaza\BannerSlider\Model\BannerFactory;

class Data extends AbstractHelper
{
	protected $_categoryCollectionFactory;
	protected $_categoryHelper;
	public $bannerFactory;
	protected $_productCollectionFactory;
	protected $_filterProvider;
	
	public function __construct(
        \Magento\Framework\App\Helper\Context $context,
		\Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryCollectionFactory,
        \Magento\Catalog\Helper\Category $categoryHelper,
		BannerFactory $bannerFactory,
		\Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
		\Magento\Cms\Model\Template\FilterProvider $filterProvider
    )
    {
		$this->_categoryCollectionFactory = $categoryCollectionFactory;
        $this->_categoryHelper = $categoryHelper;
		$this->bannerFactory = $bannerFactory;
		$this->_productCollectionFactory = $productCollectionFactory;
		$this->_filterProvider = $filterProvider;
        parent::__construct($context);
    }
	
	/**
     * Return categories helper
     */
    public function getCategoryHelper()
    {
        return $this->_categoryHelper;
    }
}