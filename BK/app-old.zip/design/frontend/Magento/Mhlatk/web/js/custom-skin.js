require([
    "jquery"
], function ($) {
	jQuery(document).ready(function(){

	/* Header Fixed Script */
	jQuery(window).scroll(function() {
		if (jQuery(window).scrollTop() > 50) {
			jQuery('header').addClass('IAmResized');
		} else {
			jQuery('header').removeClass('IAmResized');
		}
	});
	
	jQuery(window).load(function() {
		if (jQuery(window).scrollTop() > 50) {
			jQuery('header').addClass('IAmResized');
			jQuery('.scroll_top').addClass('visble_scroll');
		} else {
			jQuery('header').removeClass('IAmResized');
			jQuery('.scroll_top').removeClass('visble_scroll');
		}  
	});	

	jQuery('.click_search').click(function(){
		jQuery(this).toggleClass('remove_icon')
		jQuery('.mobile_search').slideToggle(500); 

	}); 

	jQuery('.responsive_menu_icon').click(function(){
		jQuery('.responsive_bar_popup').toggleClass('nav_visible');  
	}); 

	jQuery('.res_close_popup p').click(function(){
		jQuery('.responsive_bar_popup').removeClass('nav_visible');  
	}); 


	jQuery('.scroll_top p').click(function() {
		jQuery('html, body').animate({
			scrollTop: 0
		}, 800);
		return false;
	});

	});
});