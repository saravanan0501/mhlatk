var config = {
    paths: {
        "custom-skin": "js/custom-skin"
    }
}